# BF6 Server Blocker

Little script for blocking BF6 servers for specific region.

---

Use the provided `bf6_server_block.bat` to block and unblock servers in following region:

- Incheon, South Korea
- Tokyo, Japan
- Hong Kong, Hong Kong
- Singapore, Singapore

> https://ip-ranges.amazonaws.com/ip-ranges.json

Run once to block, run it again to unblock.
